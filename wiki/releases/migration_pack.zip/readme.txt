Step 1 - Install the plugins in the following order: 
	theme_recit-v1.15.1.zip
	format_treetopics-v1.15.1.zip
	mod_recitcahiercanada-v1.15.0.zip
	admintool_recitmigrator-v1.0.5-stable.zip
	
Step 2 - Site administration -> RÉCIT Migrate
	Follow the steps and ajust the filters.

More details here (french version) :
https://github.com/SN-RECIT-formation-a-distance/.github/wiki/Proc%C3%A9dure-de-migration-de-V1-vers-V2