Note importante!

Après l'installation des plugins, vous devez effectuer deux procédures:

1. Ajouter le bloc plan de travail au Dashboard par défaut de Moodle.
2. Migrer les cours utilisant les plugins RÉCIT V1 vers RÉCIT V2

Le pack de plugins RÉCIT ainsi que les deux procédures à suivre (en bas de page) sont disponibles à cette adresse:
https://github.com/SN-RECIT-formation-a-distance/.github/wiki 
